from django.contrib import admin
from jobs.models import JobOffer

admin.site.register(JobOffer)
